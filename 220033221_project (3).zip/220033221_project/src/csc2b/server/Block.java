package csc2b.server;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;
import java.util.List;

public class Block<T> {
	private String previousHash;
    private List<Transaction<T>> transactions;
    private long nonce;
    private String hash;

    // Constructor
    public Block(String previousHash, List<Transaction<T>> transactions) {
        this.previousHash = previousHash;
        this.transactions = transactions;
        this.nonce = 0; // Initial nonce value
        this.hash = calculateHash();
    }

    // Method to calculate the hash of the block
    public String calculateHash() {
        StringBuilder data = new StringBuilder();
        data.append(previousHash);
        for (Transaction<T> transaction : transactions) {
            data.append(transaction.toString());
        }
        data.append(nonce);
   
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hashBytes = digest.digest(data.toString().getBytes());
            return Base64.getEncoder().encodeToString(hashBytes);
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return null;
        }
    }

    // Getters
    public String getPreviousHash() {
        return previousHash;
    }

    public List<Transaction<T>> getTransactions() {
        return transactions;
    }

    public String getHash() {
        return hash;
    }

    public long getNonce() {
        return nonce;
    }

    // Setters
    public void setNonce(long nonce) {
        this.nonce = nonce;
        this.hash = calculateHash(); // Recalculate hash when nonce changes
    }

    // toString method
    @Override
    public String toString() {
        return "Block{" +
                "previousHash='" + previousHash + '\'' +
                ", transactions=" + transactions +
                ", nonce=" + nonce +
                ", hash='" + hash + '\'' +
                '}';
    }

}
