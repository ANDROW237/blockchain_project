/**
 * 
 */
package csc2b.server;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

/**
 * @author Androw\\
 *
 */
public class BlockchainServer {
	
	private ServerSocket server;
	private boolean isReady;
	

	/**
	 * 
	 */
	public BlockchainServer(int port) {
		//super();
		
		try {
			server = new ServerSocket(port);
			System.out.println("Server created on port: " + port);
			isReady = true;
			
			while(isReady)
			{
				System.out.println("Waiting to accept clients");
				Socket clientConnection = server.accept();
				// creating multiply -thread
				Thread clientThread = new Thread(new Handler(clientConnection));
				clientThread.start();
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}


	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//Setup server socket and pass on handling of request
		BlockchainServer server = new BlockchainServer(2018);    

	}

}
