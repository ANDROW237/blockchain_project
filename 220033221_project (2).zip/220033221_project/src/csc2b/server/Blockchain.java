package csc2b.server;

/**
 * 
 */

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

//import acsse.csc03a3.Block;
//import acsse.csc03a3.Transaction;

/**
 * 
 */
public class Blockchain<T> {
	private List<Block<T>> chain;
    private Map<String, Integer> stakes;

    // Constructor
    public Blockchain() {
        this.chain = new ArrayList<>();
        this.stakes = new HashMap<>();
        // Create and add the genesis block
        Block<T> genesisBlock = createGenesisBlock();
        chain.add(genesisBlock);
    }

    
    private Block<T> createGenesisBlock() {
        return new Block<>("0", new ArrayList<>());
    }  
    
    // Method to add a new block to the blockchain
    public void addBlock(List<Transaction<T>> transactions) {
        // Calculate Proof of Stake (PoS) nonce for the new block
        long nonce = calculateNonce();
        // Get previous block's hash
        String previousHash = chain.get(chain.size() - 1).getHash();
        // Create the new block
        Block<T> newBlock = new Block<>(previousHash, transactions);
        // Set the nonce
        newBlock.setNonce(nonce);
        // Add the new block to the chain
        chain.add(newBlock);
    }

    // Method to calculate the Proof of Stake (PoS) nonce for a new block
    private long calculateNonce() {
        // Your nonce calculation logic goes here
        // This method should calculate and return the nonce value
        // This is just a placeholder implementation
        return System.currentTimeMillis();
    }

    // Method to register a node's stake in the network
    public void registerStake(String nodeAddress, int stake) {
        stakes.put(nodeAddress, stake);
    }

    // Method to validate the integrity of the blockchain
    public boolean isChainValid() {
        for (int i = 1; i < chain.size(); i++) {
            Block<T> currentBlock = chain.get(i);
            Block<T> previousBlock = chain.get(i - 1);

            // Check if the current block's hash is correct
            if (!currentBlock.getHash().equals(currentBlock.calculateHash())) {
                return false;
            }  

            // Check if the previous block's hash matches the previousHash field of the current block
            if (!previousBlock.getHash().equals(currentBlock.getPreviousHash())) {
                return false;
            }
        }
        return true;
    }

    // Method to provide a string representation of the entire blockchain
    @Override
    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        for (Block<T> block : chain) {
            stringBuilder.append(block.toString()).append("\n");
        }
        return stringBuilder.toString();
    }
    
    public String selectValidator() {
        String selectedValidator = null;
        int totalStakes = 0;
        
        // Calculate total stakes in the network
        for (int stake : stakes.values()) {
            totalStakes += stake;
        }

        // Generate a random number between 0 and totalStakes
        int randomNumber = (int) (Math.random() * totalStakes);

        // Iterate over nodes to find the validator
        int accumulatedStakes = 0;
        for (Map.Entry<String, Integer> entry : stakes.entrySet()) {
            accumulatedStakes += entry.getValue();
            if (accumulatedStakes >= randomNumber) {
                selectedValidator = entry.getKey();
                break;
            }
        }

        return selectedValidator;
    }

    // return the size of the blockchain
    public int size() {
    	return chain.size();
    }
    
    /*
     * 
     * function the get a block in function of his index
     * 
     */
    public Block <T> getBlockbyIndex (int index)
    {
    	if (index >=0 && index < chain.size())
    		return chain.get(index);
    	return null; // in case the index is out of bound
    }
 /*
  * function that return the whole blockchain
  */
 public List <Block <T>> getAllChain (){
	 return chain;
 }
 
 public String getFileData (String fileId, Blockchain <String>blockchain) {
	 
	 for (Block<String>block: blockchain.getAllChain()) {
		 List <Transaction<String>> transactions = block.getTransactions();
		 
		 for (Transaction<String>transaction : transactions) {
			 
			 if (fileId.equals(transaction.getFileID()))
		 
				 return transaction.getData();
		 
		 
		 }
		 
	 }
	return null; // the file is not found in the blockchain 
	 
 }
 
    
}

