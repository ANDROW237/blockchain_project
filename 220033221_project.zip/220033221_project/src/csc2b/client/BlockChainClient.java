/**
 * 
 */
package csc2b.client;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 * @author User
 *
 */
public class BlockChainClient extends Application {

	/**
	 * @param args
	 */
	 public static void main(String[] args)
	    {
	    	//launch the JavaFX Application
	    	launch(args);
	    }

		@Override
		public void start(Stage primaryStage) throws Exception {
			//create the ClientPane, set up the Scene and Stage
				Clientpane root  = new Clientpane();
				Scene scene = new Scene(root,800,600);
				primaryStage.setTitle(" DREW_VER");
				primaryStage.setScene(scene);
				primaryStage.show();
		}

}
