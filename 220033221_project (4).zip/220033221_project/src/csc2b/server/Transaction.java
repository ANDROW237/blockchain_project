package csc2b.server;


public class Transaction<T> {
	 	private String sender;
	    private String receiver;
	    private T data;
	    private long timestamp;
		private String fileID;
  
	    // Constructor
	    public Transaction(String sender, String receiver, T data, String fileID) {
	        this.sender = sender;
	        this.receiver = receiver;
	        this.data = data;
	        this.timestamp = System.currentTimeMillis();
			this.fileID = fileID;
	    }

	    // Getter for sender
	    public String getSender() {
	        return sender;
	    }
   
	    // Setter for sender
	    public void setSender(String sender) {
	        this.sender = sender;
	    }

	    // Getter for receiver
	    public String getReceiver() {
	        return receiver;
	    }

	    // Setter for receiver
	    public void setReceiver(String receiver) {
	        this.receiver = receiver;
	    }

	    // Getter for data
	    public T getData() {
	        return data;
	    }

	    // Setter for data
	    public void setData(T data) {
	        this.data = data;
	    }

	    // Getter for timestamp
	    public long getTimestamp() {
	        return timestamp;
	    }

		

	    public String getFileID() {
			return fileID;
		}

		public void setFileID(String fileID) {
			this.fileID = fileID;
		}

		// toString method
	    @Override
	    public String toString() {
	        return "Transaction{" +
	                "sender='" + sender + '\'' +
	                ", receiver='" + receiver + '\'' +
	                ", data=" + data +
	                ", timestamp=" + timestamp +
	                '}';
	    }
}
