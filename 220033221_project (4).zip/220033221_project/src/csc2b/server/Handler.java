package csc2b.server;

//pacakage csc2b.server;

//package csc2b.server;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.StringTokenizer;
import java.util.UUID;

public class Handler implements Runnable {
	private Blockchain<String> blockchain = new Blockchain<>();
	private Socket connectionToClient;
		//Text streams
		private PrintWriter txtout=null;
		private BufferedReader txtin=null;
		
		//Binary streams
		private DataOutputStream dos=null;
		private DataInputStream dis=null;
		
		//Byte streams
		private OutputStream os=null;
		private InputStream is=null;
		
		private boolean processing;
		private boolean authenticated;
		
	    public Handler(Socket newConnectionToClient)
	    {	
	    	this.connectionToClient = newConnectionToClient;
	    	try {
	    		os = connectionToClient.getOutputStream();
	    		is =connectionToClient.getInputStream();
	    		
	    		dos = new DataOutputStream(os);
	    		dis = new DataInputStream(is);
	    		
	    		txtout = new PrintWriter(os);
	    		txtin = new BufferedReader(new InputStreamReader(is));
				
				
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    }
	    
	    
	    
	    public void run()
	    {
	    	System.out.println("Start processing commands");
	    	processing =true;
	    	
	    	try {
	    		while(processing) {
	    		
	    		String requestln = txtin.readLine();
	    		System.out.println("Got requestln: " + requestln);
	    		StringTokenizer st = new StringTokenizer(requestln);
	    		
	    		if(st.hasMoreTokens()) {
	    		String command = st.nextToken();
	    		
				if(command.equals("AUTH"))
				{
					String username = st.nextToken();
					String pass = st.nextToken();
					
					if(matchUser(username, pass))
					{
						sendMessage("200 Successfully logged in");
						authenticated = true;
						System.out.println("Logged in");
					}
					else
					{
						sendMessage("500 Unsucessful login");
						authenticated = false;	
					}	
				}
				else if(command.equals("LIST"))
				{
					String fileList = "";
					System.out.println("LIST command received");
					if(authenticated == true)
					{
						ArrayList<String> fileArrList = getFileList(blockchain);
						StringBuilder strToSend = new StringBuilder();
						for(String s: fileArrList)
						{
							strToSend.append(s).append('#');
						}
						sendMessage(strToSend.toString());
						System.out.println("StrToSend:" + strToSend);
					}
					else
					{
						sendMessage("500 Not authenticated");
					}
				}
				else if(command.equals("PDFRET"))
				{
					if(authenticated)
					{
						/*String fileID = st.nextToken();
						String fileName = idToFile(fileID);
						File pdfFile = new File("data/server/"+fileName);
						if(pdfFile.exists())
						{
							System.out.println("File found");
							sendMessage("200 " + pdfFile.length()+" bytes");
							//NB: When Sending a file
							FileInputStream fis = new FileInputStream(pdfFile);
							byte[] buffer = new byte[1024];
							int n = 0;
							while((n = fis.read(buffer))>0)//read file into byte[]
							{
								dos.write(buffer,0,n); //write the buffer on dataoutputstream
								dos.flush();
							}
							fis.close();
							
							System.out.println("File sent to client");
						}
					}
					else
					{
						sendMessage("500 Not authenticated");
					}*/
						
						String fileID = st.nextToken();
						// getting the data of the choosen from the blockchain
						String fileData = getFileData(fileID,blockchain);
						
						if (fileData !=null) {
							System.out.println("File Found");
							
							sendMessage("200" +fileData.length()+"bytes");
							
							// try to send the file contents to the client
							
							try {
								dos.write(fileData.getBytes());
								dos.flush();
								System.out.println("file sent to the client");
							}
							catch (IOException e)
							{
								e.printStackTrace();
							}
							
							
						}
						
						else
						{
							sendMessage("404 File Not Found");
						}
						
						
						
						
					}
					else
					{
						System.out.println("500 Not authicanthed");
					}
						
						
						
						
						
						
				}
				else if (command.equals("VERIFY"))
				{
				
					if(authenticated)
					{
						String Id = st.nextToken();
						
						boolean Existence = verification(Id ,blockchain);
						
						if (Existence) {sendMessage("200 File found in the blockchain");}
					
						else 
							sendMessage ("404 File doesnt exist in the blockchain ");
					
					}
					
					else
					{
						sendMessage("500 Not authenticated");
					}
					
					
					
				}
				
				else if (command.equals("UPLOAD"))
				{
				
					if(authenticated)
					{
						String name = st.nextToken();
						int fileSize = Integer.parseInt(st.nextToken());
						byte [] filedata =new byte[fileSize];
						dis.readFully(filedata);
						UploadCommand(name,filedata);
					}
					
					else
					{
						sendMessage("500 Not authenticated");
					}
					
					
					
				}
				
				
				else if(command.equals("LOGOUT"))
				{
					if(authenticated)
					{
						authenticated = false;
						sendMessage("200 Logged out");
						dos.close();
						dis.close();
						
						txtin.close();
						txtout.close();
						connectionToClient.close();
						processing = false;	
					}
					else
					{
						sendMessage("500 Not authenticated");
					}
				}
				
	    		}else
				{
					//invalid command
				}
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    	finally
	    	{
	    		System.out.println("Finally");
	    	}
	    	
	    	
	    }
	    
	    private void sendMessage(String message)
	    {
	    	txtout.println(message);
	    	txtout.flush();
	    }
	    
	    private boolean matchUser(String username,String password)
	    {
		boolean found = false;
		File userFile = new File("data/server/users.txt");
		try
		{
		    Scanner scan = new Scanner(userFile);
		    while(scan.hasNextLine()&&!found)
		    {
			String line = scan.nextLine();
			String lineSec[] = line.split("\\s");
	    		
			//Compare user 
				if(username.equals(lineSec[0])&& password.equals(lineSec[1]))
				{
					found = true;
				}
		    }
		    scan.close();
		}
		catch(IOException ex)
		{
		    ex.printStackTrace();
		}
		
		return found;
	    }
	    
	    
	    /*
	     * function that get the list of file in the blockchain
	     */
	    private ArrayList<String> getFileList(Blockchain<String> blockchain)
	    {
			/*
			 * ArrayList<String> result = new ArrayList<String>(); File lstFile = new
			 * File("data/server/PdfList.txt"); try { Scanner scan = new Scanner(lstFile);
			 * while(scan.hasNext()) { result.add(scan.nextLine()); } //Read in each line of
			 * file scan.close(); } catch(IOException ex) { ex.printStackTrace(); } return
			 * result;
			 */
	    	// creating an arrayList of the file int the blockchain
	    	ArrayList <String> fileList = new ArrayList<>();
	    	
	    	for (Block <String> block : blockchain.getAllChain()) {
	    		
	    		List<Transaction<String>> transactions = block.getTransactions();
	    		
	    		 for (Transaction<String>transaction : transactions) {
	    			 
	    			 String fileID = transaction.getData();
	    			 
	    			 fileList.add(fileID);
	    		 }
	    	
	    	
	    	}
	    	
	    	return fileList;
	    	
	    }
	    
		/*
		 * private String idToFile(String ID) { String result = ""; File lstFile = new
		 * File("data/server/PdfList.txt"); try { Scanner scan = new Scanner(lstFile);
		 * String line = ""; while(scan.hasNext()) { line = scan.nextLine();
		 * StringTokenizer tokenizer = new StringTokenizer(line); String strid =
		 * tokenizer.nextToken(); String fileName = tokenizer.nextToken();
		 * if(strid.equals(ID)) { result = fileName; } } //Read filename from file
		 * 
		 * scan.close(); } catch(IOException ex) { ex.printStackTrace(); } return
		 * result; }
		 */

	    
	    
	    /*
	     * function that get the ID  of  the choosen file in the blockchain
	     */
	    private String idToFile(String ID, Blockchain<String> blockchain) {
	        List<Block<String>> blocks = blockchain.getAllChain(); // creating  a list of bloccks
	        
	         // going through eack of the list of the blocks
	        for (Block<String> block : blocks) {
	            // creating  the list of transactions
	        	List<Transaction<String>> transactions = block.getTransactions();
	            
	        //	going through of each transactions
	        	for (Transaction<String> transaction : transactions) {
	              
	                String fileId = transaction.getFileID();
	                if (fileId != null && fileId.equals(ID)) {
	                    return transaction.getData(); }
	            }
	        }
	        return null; // File not found in the blockchain
	    }

	
	    
	    /*
	     * function that get the data of  the choosen file in the blockchain
	     */
	    
	    public String getFileData (String fileId, Blockchain <String>blockchain) {
	   	 
	   	 for (Block<String>block: blockchain.getAllChain()) {
	   		 List <Transaction<String>> transactions = block.getTransactions();
	   		 
	   		 for (Transaction<String>transaction : transactions) {
	   			 
	   			 if (fileId.equals(transaction.getFileID()))
	   		 
	   				 return transaction.getData();
	   		 
	   		 
	   		 }
	   		 
	   	 }
	   	return null; // the file is not found in the blockchain 
	   	 
	    }
	    
	
	    // hashing function, 
	private String hashing (byte[]fileData) {
		
		try {
			MessageDigest digest = MessageDigest.getInstance("SHA-256");
			byte[] arrBytes = digest.digest(fileData);
			
			// convert the hashbyte array of bytes to hexadecimal string 
			
			StringBuilder hexString = new StringBuilder(); // creating a stringBuilder
			
			// going through each byte of the arrbytes
			for (byte b : arrBytes)
				
			{
				String hex = Integer.toHexString(0xff & b);
				if (hex.length()==1) {
					
					hexString.append('0');
				}
				hexString.append(hex);
			}
			
			return hexString.toString();
		
		
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
			
			return null;
		}
		
		
		
		
	}
	    


	
	private  void UploadCommand (String fileName , byte[] fileData)
	{
		// hashing the file that we want to upload
		
		String fileHashed =hashing(fileData);
		
		if (fileHashed != null)
		{
			String sender = "Client";
			String receiver = "blockchain";
			// generating an unique fileId
			
			String fileId = UUID.randomUUID().toString();
			
	//	Transaction <byte[]> transaction = new Transaction<>(sender,receiver,fileData,fileId);// creating a new transaction
		
		blockchain.addtransaction (fileData, sender,receiver, fileId);
		
		sendMessage("200 Upload successful. File ID:"+ fileId);
		}
		
		else
		{
			sendMessage ("500 Something went south");
		}
		
		
		
	}
	
	 // function to verify if the file does exist in the blockchain
	private boolean verification (String fileId , Blockchain<String> blockchain) {
		List <Block <String>> blocklist = blockchain.getAllChain();
		
		// going through  each block of the blocklist
		for (Block <String> block : blocklist)
		{
			// creating a list of transactions 
			List <Transaction <String>> transactions = block.getTransactions();	
		
		// going through  each transaction of the list of transactions
			for (Transaction <String> transaction :transactions)
				
			{
				String Id = transaction.getFileID();
				
				// as long the id we are looking for it is not null
				if (Id !=null && Id.equals(fileId)) 
					return true; // the file was found
				
			}
		}
		
		return false;
	}
	
	    
	
	
}
